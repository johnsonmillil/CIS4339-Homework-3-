[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=12072819&assignment_repo_type=AssignmentRepo)
# Template

This is the starter template for HW2.

Don't forgte to make a commit after you are done with Part 1. The commit message should say "Finished Part1".

